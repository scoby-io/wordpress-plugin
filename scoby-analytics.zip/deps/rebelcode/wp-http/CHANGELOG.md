# Change log
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/)
and this project adheres to [Semantic Versioning](http://semver.org/).

## [0.3] - 2021-07-26
### Fixed
- Empty response status codes no longer trigger an exception about status code range

## [0.2] - 2021-06-23
### Changed
- Using stable dependency versions

## [0.1] - 2021-06-23
Initial version.
