<?php

namespace ScobyAnalyticsDeps\Psr\Container;

/**
 * No entry was found in the container.
 * @internal
 */
interface NotFoundExceptionInterface extends ContainerExceptionInterface
{
}
