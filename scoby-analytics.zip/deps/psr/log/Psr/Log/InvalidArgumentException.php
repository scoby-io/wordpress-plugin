<?php

namespace ScobyAnalyticsDeps\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
