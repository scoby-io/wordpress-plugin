<?php

namespace ScobyAnalyticsDeps\Psr\Log;

/** @internal */
class InvalidArgumentException extends \InvalidArgumentException
{
}
