<?php

namespace ScobyAnalyticsDeps\Http\Discovery\Exception;

use ScobyAnalyticsDeps\Http\Discovery\Exception;
/**
 * Thrown when a class fails to instantiate.
 *
 * @author Tobias Nyholm <tobias.nyholm@gmail.com>
 * @internal
 */
final class ClassInstantiationFailedException extends \RuntimeException implements Exception
{
}
