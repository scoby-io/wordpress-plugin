# Changelog

All notable changes to `macroable` will be documented in this file

## 1.0.1 - 2020-11-03

- add support for PHP 8.0
- drop support for PHP 7.1 and below

## 1.0.0 - 2017-09-16

- initial release
